# How to Add Desktop Fences (Windows, MacBook, iOS & Android) to Your Portfolio Website

This archive is **100% self-contained** and ready to host inside any portfolio website (Next.js, React/Vite, Vercel, Netlify, GitHub Pages, or plain HTML).

## 1. Drop Into Your Portfolio Folder
1. Extract this `.zip` into a folder named **`desktop-fences-pwa`** inside your website's static/public folder:
   - **Next.js / Vite / Create React App:** Put `desktop-fences-pwa/` inside your `public/` folder (`public/desktop-fences-pwa/`).
   - **Plain HTML / GitHub Pages / Netlify:** Put `desktop-fences-pwa/` right beside your portfolio's `index.html`.
2. Copy the ready-made HTML card from **`portfolio-embed-card.html`** and paste it into your portfolio's Projects section!

## 2. How Visitors Download & Install on Every Platform
- **Windows 10 & Windows 11:**
  - Visitors can download **`DesktopFences-Setup-v1.0.0-win-x64.exe`** (One-Click Native Windows Installer) or **`DesktopFences-Portable-v1.0.0-win-x64.zip`**, OR click **Install App** in Edge/Chrome to install the Desktop PWA.
- **Apple MacBook (macOS):**
  - Visitors open `/desktop-fences-pwa/index.html` and click **Install App on MacBook** (or Safari **File → Add to Dock…** / Chrome address-bar install icon) to run it as a standalone macOS Dock app with offline support.
- **iOS (iPhone & iPad):**
  - Visitors open `/desktop-fences-pwa/index.html` in Safari → tap **Share → Add to Home Screen** (includes full-screen `apple-mobile-web-app-capable` metadata and 180×180 `apple-touch-icon.png`).
- **Android:**
  - Visitors open `/desktop-fences-pwa/index.html` in Chrome and tap **Install on Android** (`beforeinstallprompt` WebAPK) to add it directly to their Android App Drawer & Home Screen.
