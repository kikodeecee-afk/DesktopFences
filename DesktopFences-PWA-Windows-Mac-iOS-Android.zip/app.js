(() => {
  'use strict';

  // Register Offline-Ready Service Worker
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    });
  }

  const THEMES = [
    { name: 'Transparent', accent: '#60A5FA', darkBg: 'rgba(13,19,31,0.22)', lightBg: 'rgba(248,250,252,0.28)', transparent: true },
    { name: 'Navy Blue', accent: '#1E3A8A', darkBg: 'rgba(16,25,53,0.84)', lightBg: 'rgba(232,239,253,0.86)' },
    { name: 'Rose Pink', accent: '#EC4899', darkBg: 'rgba(45,18,34,0.84)', lightBg: 'rgba(252,235,244,0.86)' },
    { name: 'Midnight Ocean', accent: '#3B82F6', darkBg: 'rgba(17,28,51,0.84)', lightBg: 'rgba(235,243,254,0.86)' },
    { name: 'Obsidian Slate', accent: '#64748B', darkBg: 'rgba(20,23,32,0.84)', lightBg: 'rgba(243,244,246,0.86)' },
    { name: 'Emerald Moss', accent: '#10B981', darkBg: 'rgba(15,38,32,0.84)', lightBg: 'rgba(233,251,244,0.86)' },
    { name: 'Royal Amethyst', accent: '#8B5CF6', darkBg: 'rgba(30,21,51,0.84)', lightBg: 'rgba(242,238,254,0.86)' },
    { name: 'Sunset Amber', accent: '#F59E0B', darkBg: 'rgba(43,31,14,0.84)', lightBg: 'rgba(254,245,231,0.86)' },
    { name: 'Crimson Ruby', accent: '#F43F5E', darkBg: 'rgba(45,18,25,0.84)', lightBg: 'rgba(254,236,239,0.86)' },
    { name: 'Nordic Ice', accent: '#06B6D4', darkBg: 'rgba(14,36,43,0.84)', lightBg: 'rgba(232,250,253,0.86)' }
  ];

  const STORAGE_KEY = 'desktop_fences_pwa_state_v4';

  const defaultState = () => ({
    isDarkMode: true,
    lockAll: false,
    items: [
      { id: 'it-1', name: 'Recycle Bin', icon: '🗑️', bg: 'linear-gradient(135deg,#475569,#1e293b)', url: '#recycle', size: 0, type: 'System Desktop Icon', modified: Date.now() - 900000, owner: 'desktop' },
      { id: 'it-2', name: 'Learn about this picture', icon: '🏞️', bg: 'linear-gradient(135deg,#0ea5e9,#0369a1)', url: 'https://www.bing.com/spotlight', size: 12, type: 'System Desktop Icon', modified: Date.now() - 800000, owner: 'desktop' },
      { id: 'it-3', name: 'VS Code', icon: '💻', bg: 'linear-gradient(135deg,#2563eb,#1d4ed8)', url: 'https://vscode.dev', size: 94200, type: 'Application', modified: Date.now() - 500000, owner: 'f-apps' },
      { id: 'it-4', name: 'GitHub', icon: '🐙', bg: 'linear-gradient(135deg,#334155,#0f172a)', url: 'https://github.com/kikodeecee-afk/DesktopFences', size: 4200, type: 'Web Shortcut', modified: Date.now() - 300000, owner: 'f-apps' },
      { id: 'it-5', name: 'Discord', icon: '🎧', bg: 'linear-gradient(135deg,#6366f1,#4338ca)', url: 'https://discord.com/app', size: 88500, type: 'Application', modified: Date.now() - 200000, owner: 'f-apps' },
      { id: 'it-6', name: 'Figma Design', icon: '🎨', bg: 'linear-gradient(135deg,#ec4899,#8b5cf6)', url: 'https://figma.com', size: 51200, type: 'Application', modified: Date.now() - 120000, owner: 'f-apps' },
      { id: 'it-7', name: 'Projects Folder', icon: '📁', bg: 'linear-gradient(135deg,#f59e0b,#d97706)', url: '#folder', size: -1, type: 'File folder', modified: Date.now() - 400000, owner: 'f-docs' },
      { id: 'it-8', name: 'Portfolio Assets', icon: '📁', bg: 'linear-gradient(135deg,#f59e0b,#d97706)', url: '#folder', size: -1, type: 'File folder', modified: Date.now() - 150000, owner: 'f-docs' },
      { id: 'it-9', name: 'Tutorial Manual.pdf', icon: '📄', bg: 'linear-gradient(135deg,#ef4444,#b91c1c)', url: './downloads/Read%20me%20Fence%20Tutorial%20and%20Functionality.pdf', size: 16236, type: 'Document', modified: Date.now(), owner: 'f-docs' }
    ],
    fences: [
      { id: 'f-apps', title: 'Work & Apps', x: 230, y: 24, w: 390, h: 270, theme: 'Transparent', sortBy: 'None', sortDesc: false, holdLock: false, moveMode: 'Anywhere', rolledUp: false },
      { id: 'f-docs', title: 'Documents & Projects', x: 650, y: 24, w: 390, h: 270, theme: 'Navy Blue', sortBy: 'Name', sortDesc: false, holdLock: false, moveMode: 'Anywhere', rolledUp: false }
    ]
  });

  let state = loadState();
  let selectedItemIds = new Set();
  let activeSortFenceId = null;
  let deferredInstallPrompt = null;

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (_) {}
    return defaultState();
  }

  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) {}
  }

  function getTheme(name) {
    return THEMES.find((t) => t.name === name) || THEMES[0];
  }

  function sortItems(items, fence) {
    if (!fence || !fence.sortBy || fence.sortBy === 'None') return items;
    const copy = [...items];
    const dir = fence.sortDesc ? -1 : 1;
    copy.sort((a, b) => {
      let cmp = 0;
      if (fence.sortBy === 'Name') {
        cmp = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
      } else if (fence.sortBy === 'Size') {
        cmp = (a.size || 0) - (b.size || 0);
      } else if (fence.sortBy === 'ItemType') {
        cmp = (a.type || '').localeCompare(b.type || '') || a.name.localeCompare(b.name);
      } else if (fence.sortBy === 'DateModified') {
        cmp = (a.modified || 0) - (b.modified || 0);
      }
      return cmp * dir;
    });
    return copy;
  }

  function renderAll() {
    document.body.classList.toggle('dark-mode', state.isDarkMode);
    document.body.classList.toggle('light-mode', !state.isDarkMode);
    const themeBtn = document.getElementById('btnThemeMode');
    if (themeBtn) themeBtn.textContent = state.isDarkMode ? '🌙 Dark' : '☀ Light';

    // 1. Render Unfenced Desktop Icons (Zero Duplicates: strictly owner === 'desktop')
    const desktopTray = document.getElementById('openDesktopTray');
    desktopTray.innerHTML = '';
    state.items.filter((i) => i.owner === 'desktop').forEach((item) => {
      desktopTray.appendChild(createIconTile(item));
    });

    desktopTray.ondragover = (e) => { e.preventDefault(); };
    desktopTray.ondrop = (e) => {
      e.preventDefault();
      transferDraggedItemsTo('desktop');
    };

    // 2. Render Fences
    const container = document.getElementById('fencesContainer');
    container.innerHTML = '';
    state.fences.forEach((fence) => {
      container.appendChild(createFenceElement(fence));
    });
  }

  function createIconTile(item) {
    const tile = document.createElement('div');
    tile.className = 'icon-tile' + (selectedItemIds.has(item.id) ? ' selected' : '');
    tile.dataset.id = item.id;
    tile.draggable = true;
    tile.title = `${item.name} (${item.type})`;

    tile.innerHTML = `
      <div class="tile-check">✓</div>
      <div class="icon-glyph" style="background:${item.bg || 'linear-gradient(135deg,#3b82f6,#1d4ed8)'}">${item.icon || '📦'}</div>
      <div class="icon-label">${escapeHtml(item.name)}</div>
    `;

    tile.addEventListener('click', (e) => {
      e.stopPropagation();
      if (e.ctrlKey || e.metaKey) {
        if (selectedItemIds.has(item.id)) selectedItemIds.delete(item.id);
        else selectedItemIds.add(item.id);
      } else {
        selectedItemIds.clear();
        selectedItemIds.add(item.id);
      }
      refreshSelectionClasses();
    });

    tile.addEventListener('dblclick', (e) => {
      e.stopPropagation();
      launchItem(item);
    });

    tile.addEventListener('dragstart', (e) => {
      if (!selectedItemIds.has(item.id)) {
        selectedItemIds.clear();
        selectedItemIds.add(item.id);
        refreshSelectionClasses();
      }
      e.dataTransfer.setData('text/plain', JSON.stringify([...selectedItemIds]));
    });

    tile.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!selectedItemIds.has(item.id)) {
        selectedItemIds.clear();
        selectedItemIds.add(item.id);
        refreshSelectionClasses();
      }
      openItemContextMenu(e.clientX, e.clientY, item);
    });

    return tile;
  }

  function createFenceElement(fence) {
    const theme = getTheme(fence.theme);
    const box = document.createElement('div');
    box.className = 'fence-box' +
      (theme.transparent ? ' transparent-mode transparent-idle' : '') +
      (fence.rolledUp ? ' rolled-up' : '');
    box.dataset.fenceId = fence.id;
    box.style.left = fence.x + 'px';
    box.style.top = fence.y + 'px';
    box.style.width = fence.w + 'px';
    box.style.height = (fence.rolledUp ? 40 : fence.h) + 'px';
    applyFenceColors(box, fence, false);

    const ownedItems = sortItems(state.items.filter((i) => i.owner === fence.id), fence);

    box.innerHTML = `
      <div class="fence-header">
        <div class="fence-title-wrap">
          <span class="fence-title">${escapeHtml(fence.title)}</span>
          <span class="fence-badge">${ownedItems.length}</span>
        </div>
        <div class="fence-controls">
          <button class="hdr-icon-btn btn-color" title="Fence Color Theme">🎨</button>
          <button class="hdr-icon-btn btn-sort" title="Sort by Option Buttons">⇅</button>
          <button class="hdr-icon-btn btn-rollup" title="Roll-Up Fence">${fence.rolledUp ? '▸' : '▾'}</button>
        </div>
      </div>
      <div class="fence-body">
        ${ownedItems.length === 0 ? '<div class="empty-fence-hint">Drag desktop icons here • Hold Right-Click to Multi-Select</div>' : ''}
      </div>
      <div class="resize-grip-se" title="Resize Fence"></div>
    `;

    const header = box.querySelector('.fence-header');
    const body = box.querySelector('.fence-body');
    ownedItems.forEach((it) => body.appendChild(createIconTile(it)));

    // Transparent Hover-Reveal Pop-Out
    box.addEventListener('mouseenter', () => {
      box.classList.remove('transparent-idle');
      applyFenceColors(box, fence, true);
      if (fence.rolledUp) box.style.height = fence.h + 'px';
    });

    box.addEventListener('mouseleave', () => {
      if (theme.transparent) box.classList.add('transparent-idle');
      applyFenceColors(box, fence, false);
      if (fence.rolledUp) box.style.height = '40px';
    });

    // Double-click title to rename inline
    header.addEventListener('dblclick', (e) => {
      if (e.target.closest('button')) return;
      const titleSpan = header.querySelector('.fence-title');
      const input = document.createElement('input');
      input.className = 'fence-title-input';
      input.value = fence.title;
      titleSpan.replaceWith(input);
      input.focus();
      input.select();
      const commit = () => {
        if (input.value.trim()) fence.title = input.value.trim();
        saveState();
        renderAll();
      };
      input.addEventListener('blur', commit);
      input.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') input.blur();
        if (ev.key === 'Escape') renderAll();
      });
    });

    header.querySelector('.btn-color').addEventListener('click', (e) => {
      e.stopPropagation();
      openFenceContextMenu(e.clientX, e.clientY, fence);
    });

    header.querySelector('.btn-sort').addEventListener('click', (e) => {
      e.stopPropagation();
      openSortModal(fence);
    });

    header.querySelector('.btn-rollup').addEventListener('click', (e) => {
      e.stopPropagation();
      fence.rolledUp = !fence.rolledUp;
      saveState();
      renderAll();
    });

    // Drag-and-Drop Transfer into Fence (Zero Duplicates)
    box.addEventListener('dragover', (e) => {
      e.preventDefault();
      box.classList.remove('transparent-idle');
      applyFenceColors(box, fence, true);
    });
    box.addEventListener('drop', (e) => {
      e.preventDefault();
      e.stopPropagation();
      transferDraggedItemsTo(fence.id);
    });

    // Right-click menu inside fence
    box.addEventListener('contextmenu', (e) => {
      if (box.dataset.suppressMenu === '1') {
        box.dataset.suppressMenu = '0';
        e.preventDefault();
        return;
      }
      e.preventDefault();
      openFenceContextMenu(e.clientX, e.clientY, fence);
    });

    // Anchor-Based 1:1 Fence Dragging (Header + Anywhere in Empty Body) & Marquee Multi-Select
    attachFencePointerInteractions(box, header, body, fence);

    // 1:1 Anchor Resize Grip
    const grip = box.querySelector('.resize-grip-se');
    grip.addEventListener('pointerdown', (e) => {
      if (isFenceLocked(fence) || fence.rolledUp) return;
      e.stopPropagation();
      grip.setPointerCapture(e.pointerId);
      const startX = e.clientX, startY = e.clientY;
      const startW = fence.w, startH = fence.h;
      const onMove = (ev) => {
        fence.w = Math.max(210, startW + (ev.clientX - startX));
        fence.h = Math.max(140, startH + (ev.clientY - startY));
        box.style.width = fence.w + 'px';
        box.style.height = fence.h + 'px';
      };
      const onUp = () => {
        grip.removeEventListener('pointermove', onMove);
        grip.removeEventListener('pointerup', onUp);
        saveState();
      };
      grip.addEventListener('pointermove', onMove);
      grip.addEventListener('pointerup', onUp);
    });

    return box;
  }

  function isFenceLocked(fence) {
    return state.lockAll || fence.holdLock || fence.moveMode === 'Locked';
  }

  function attachFencePointerInteractions(box, header, body, fence) {
    // Header drag
    header.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('button') || e.target.closest('input') || isFenceLocked(fence)) return;
      startBoxMove(e, box, fence);
    });

    // Body interactions: Left-drag empty space moves fence (unless locked/Shift); Right-drag or Shift-drag does Marquee Multi-Select!
    body.addEventListener('mousedown', (e) => {
      if (e.target.closest('.icon-tile')) {
        if (e.button === 2) startMarqueeSelection(e, box, body);
        return;
      }

      if (e.button === 2 || e.shiftKey || e.ctrlKey || isFenceLocked(fence) || fence.moveMode === 'HeaderOnly') {
        if (!e.shiftKey && !e.ctrlKey && e.button === 0) {
          selectedItemIds.clear();
          refreshSelectionClasses();
        }
        startMarqueeSelection(e, box, body);
        return;
      }

      if (e.button === 0) {
        selectedItemIds.clear();
        refreshSelectionClasses();

        if (fence.moveMode === 'HoldDelay') {
          let timerFired = false;
          const holdTimer = setTimeout(() => {
            timerFired = true;
            body.style.cursor = 'move';
            startBoxMoveMouse(e, box, fence, () => { body.style.cursor = ''; });
          }, 350);
          const cancelEarly = (mv) => {
            if (!timerFired && (Math.abs(mv.clientX - e.clientX) > 6 || Math.abs(mv.clientY - e.clientY) > 6)) {
              clearTimeout(holdTimer);
              window.removeEventListener('mousemove', cancelEarly);
              startMarqueeSelection(e, box, body);
            }
          };
          window.addEventListener('mousemove', cancelEarly);
          window.addEventListener('mouseup', () => {
            clearTimeout(holdTimer);
            window.removeEventListener('mousemove', cancelEarly);
          }, { once: true });
        } else {
          startBoxMoveMouse(e, box, fence);
        }
      }
    });
  }

  function startBoxMove(e, box, fence) {
    const startX = e.clientX, startY = e.clientY;
    const origX = fence.x, origY = fence.y;
    const onMove = (ev) => {
      fence.x = Math.max(8, origX + (ev.clientX - startX));
      fence.y = Math.max(8, origY + (ev.clientY - startY));
      box.style.left = fence.x + 'px';
      box.style.top = fence.y + 'px';
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      saveState();
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  }

  function startBoxMoveMouse(e, box, fence, onDone) {
    const startX = e.clientX, startY = e.clientY;
    const origX = fence.x, origY = fence.y;
    const onMove = (ev) => {
      if (Math.abs(ev.clientX - startX) < 4 && Math.abs(ev.clientY - startY) < 4) return;
      fence.x = Math.max(8, origX + (ev.clientX - startX));
      fence.y = Math.max(8, origY + (ev.clientY - startY));
      box.style.left = fence.x + 'px';
      box.style.top = fence.y + 'px';
    };
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      if (onDone) onDone();
      saveState();
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }

  function startMarqueeSelection(e, box, body) {
    const rectStart = body.getBoundingClientRect();
    const startX = e.clientX - rectStart.left;
    const startY = e.clientY - rectStart.top + body.scrollTop;
    const initialSet = (e.shiftKey || e.ctrlKey) ? new Set(selectedItemIds) : new Set();
    let marqueeEl = null;

    const onMove = (ev) => {
      const curX = ev.clientX - rectStart.left;
      const curY = ev.clientY - rectStart.top + body.scrollTop;
      const dx = Math.abs(curX - startX), dy = Math.abs(curY - startY);
      if (!marqueeEl) {
        if (dx < 5 && dy < 5) return;
        marqueeEl = document.createElement('div');
        marqueeEl.className = 'marquee-box';
        body.appendChild(marqueeEl);
        if (e.button === 2) box.dataset.suppressMenu = '1';
      }
      const left = Math.min(startX, curX);
      const top = Math.min(startY, curY);
      marqueeEl.style.left = left + 'px';
      marqueeEl.style.top = top + 'px';
      marqueeEl.style.width = dx + 'px';
      marqueeEl.style.height = dy + 'px';

      selectedItemIds = new Set(initialSet);
      const mRect = marqueeEl.getBoundingClientRect();
      body.querySelectorAll('.icon-tile').forEach((tile) => {
        const tRect = tile.getBoundingClientRect();
        const hit = !(tRect.right < mRect.left || tRect.left > mRect.right || tRect.bottom < mRect.top || tRect.top > mRect.bottom);
        if (hit) selectedItemIds.add(tile.dataset.id);
      });
      refreshSelectionClasses();
    };

    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      if (marqueeEl) marqueeEl.remove();
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }

  function applyFenceColors(box, fence, isHovered) {
    const theme = getTheme(fence.theme);
    const header = box.querySelector('.fence-header');
    if (theme.transparent && !isHovered) {
      box.style.background = 'rgba(0,0,0,0.004)';
      box.style.borderColor = 'transparent';
      return;
    }
    box.style.background = state.isDarkMode ? theme.darkBg : theme.lightBg;
    box.style.borderColor = theme.accent;
    if (header) header.style.background = theme.accent + '66';
  }

  function transferDraggedItemsTo(targetOwner) {
    if (selectedItemIds.size === 0) return;
    state.items.forEach((it) => {
      if (selectedItemIds.has(it.id)) it.owner = targetOwner;
    });
    saveState();
    renderAll();
  }

  function refreshSelectionClasses() {
    document.querySelectorAll('.icon-tile').forEach((el) => {
      el.classList.toggle('selected', selectedItemIds.has(el.dataset.id));
    });
  }

  function launchItem(item) {
    if (!item.url || item.url.startsWith('#')) {
      alert(`${item.name}\nType: ${item.type}`);
      return;
    }
    window.open(item.url, '_blank', 'noopener');
  }

  // Context Menus
  const ctxMenu = document.getElementById('contextMenu');
  window.addEventListener('click', () => ctxMenu.classList.add('hidden'));

  // Bug fix: clicking anywhere OUTSIDE a fence (wallpaper, dock, empty desktop) un-highlights selected icons
  document.addEventListener('mousedown', (e) => {
    if (selectedItemIds.size === 0) return;
    if (e.target.closest && e.target.closest('.fence-box, #contextMenu, [id$="Modal"]')) return;
    selectedItemIds.clear();
    refreshSelectionClasses();
  });
  document.addEventListener('touchstart', (e) => {
    if (selectedItemIds.size === 0) return;
    if (e.target.closest && e.target.closest('.fence-box, #contextMenu, [id$="Modal"]')) return;
    selectedItemIds.clear();
    refreshSelectionClasses();
  }, { passive: true });

  function showMenuAt(x, y, html) {
    ctxMenu.innerHTML = html;
    ctxMenu.classList.remove('hidden');
    const maxLeft = window.innerWidth - 250;
    const maxTop = window.innerHeight - ctxMenu.offsetHeight - 12;
    ctxMenu.style.left = Math.max(8, Math.min(x, maxLeft)) + 'px';
    ctxMenu.style.top = Math.max(8, Math.min(y, maxTop)) + 'px';
  }

  function openFenceContextMenu(x, y, fence) {
    const locked = isFenceLocked(fence);
    const sortLabel = fence.sortBy && fence.sortBy !== 'None' ? `${fence.sortBy} (${fence.sortDesc ? '↓' : '↑'})` : 'Manual';
    showMenuAt(x, y, `
      <div class="ctx-section-title">Auto-Sort (${sortLabel})</div>
      <div class="ctx-item" data-act="sort-Name"><span>${fence.sortBy === 'Name' ? '◉' : '○'} Sort by: Name</span></div>
      <div class="ctx-item" data-act="sort-Size"><span>${fence.sortBy === 'Size' ? '◉' : '○'} Sort by: Size</span></div>
      <div class="ctx-item" data-act="sort-ItemType"><span>${fence.sortBy === 'ItemType' ? '◉' : '○'} Sort by: Item Type</span></div>
      <div class="ctx-item" data-act="sort-DateModified"><span>${fence.sortBy === 'DateModified' ? '◉' : '○'} Sort by: Date Modified</span></div>
      <div class="ctx-item" data-act="sort-modal"><span>⚙ Auto-Sort Option Panel...</span></div>
      <div class="ctx-sep"></div>
      <div class="ctx-section-title">Hold & Movement</div>
      <div class="ctx-item" data-act="toggle-hold"><span>${locked ? '☑' : '☐'} 🔒 Hold / Lock Fence Position</span></div>
      <div class="ctx-item" data-act="mode-Anywhere"><span>${!locked && fence.moveMode === 'Anywhere' ? '◉' : '○'} Drag Anywhere Inside Box</span></div>
      <div class="ctx-item" data-act="mode-HoldDelay"><span>${!locked && fence.moveMode === 'HoldDelay' ? '◉' : '○'} Hold Left-Click (0.35s) to Move</span></div>
      <div class="ctx-sep"></div>
      <div class="ctx-section-title">Fence Color Theme</div>
      ${THEMES.slice(0, 6).map((t) => `<div class="ctx-item" data-theme="${t.name}"><span>${fence.theme === t.name ? '◉' : '○'} ${t.name === 'Transparent' ? '✨ Transparent (Hover)' : t.name}</span></div>`).join('')}
      <div class="ctx-sep"></div>
      <div class="ctx-item" data-act="restore-fence"><span>↩ Return Icons to Desktop</span></div>
      <div class="ctx-item" data-act="delete-fence"><span>🗑 Delete Fence</span></div>
    `);

    ctxMenu.querySelectorAll('[data-act]').forEach((el) => {
      el.onclick = () => {
        const act = el.dataset.act;
        if (act.startsWith('sort-') && act !== 'sort-modal') {
          const mode = act.slice(5);
          if (fence.sortBy === mode) fence.sortDesc = !fence.sortDesc;
          else { fence.sortBy = mode; fence.sortDesc = false; }
        } else if (act === 'sort-modal') {
          openSortModal(fence);
          return;
        } else if (act === 'toggle-hold') {
          fence.holdLock = !locked;
          fence.moveMode = fence.holdLock ? 'Locked' : 'Anywhere';
        } else if (act.startsWith('mode-')) {
          fence.holdLock = false;
          fence.moveMode = act.slice(5);
        } else if (act === 'restore-fence') {
          state.items.forEach((i) => { if (i.owner === fence.id) i.owner = 'desktop'; });
        } else if (act === 'delete-fence') {
          if (state.fences.length <= 1) return alert('Keep at least one fence active.');
          state.items.forEach((i) => { if (i.owner === fence.id) i.owner = 'desktop'; });
          state.fences = state.fences.filter((f) => f.id !== fence.id);
        }
        saveState();
        renderAll();
      };
    });

    ctxMenu.querySelectorAll('[data-theme]').forEach((el) => {
      el.onclick = () => {
        fence.theme = el.dataset.theme;
        saveState();
        renderAll();
      };
    });
  }

  function openItemContextMenu(x, y, item) {
    const count = Math.max(1, selectedItemIds.size);
    const suffix = count > 1 ? ` (${count} selected)` : '';
    showMenuAt(x, y, `
      <div class="ctx-item" data-iact="open"><strong>Open${suffix}</strong></div>
      ${item.owner !== 'desktop' ? `<div class="ctx-item" data-iact="to-desktop"><span>🖥 Move Back to Desktop${suffix}</span></div>` : ''}
      ${state.fences.filter((f) => f.id !== item.owner).map((f) => `<div class="ctx-item" data-tofence="${f.id}"><span>▣ Move to ${escapeHtml(f.title)}</span></div>`).join('')}
      <div class="ctx-sep"></div>
      <div class="ctx-item" data-iact="delete"><span>🗑 Remove Shortcut${suffix}</span></div>
    `);

    ctxMenu.querySelectorAll('[data-iact]').forEach((el) => {
      el.onclick = () => {
        const a = el.dataset.iact;
        if (a === 'open') launchItem(item);
        else if (a === 'to-desktop') transferDraggedItemsTo('desktop');
        else if (a === 'delete') {
          state.items = state.items.filter((i) => !selectedItemIds.has(i.id));
          selectedItemIds.clear();
          saveState();
          renderAll();
        }
      };
    });

    ctxMenu.querySelectorAll('[data-tofence]').forEach((el) => {
      el.onclick = () => transferDraggedItemsTo(el.dataset.tofence);
    });
  }

  // Sort Option Buttons Modal
  function openSortModal(fence) {
    activeSortFenceId = fence.id;
    document.getElementById('sortModalTitle').textContent = `Auto-Sort — ${fence.title}`;
    const curMode = fence.sortBy || 'None';
    document.querySelectorAll('input[name="sortByOpt"]').forEach((rb) => {
      rb.checked = rb.value === curMode;
      rb.onchange = () => {
        fence.sortBy = rb.value;
        saveState();
        renderAll();
      };
    });
    document.querySelectorAll('input[name="sortDirOpt"]').forEach((rb) => {
      rb.checked = (rb.value === 'desc') === !!fence.sortDesc;
      rb.onchange = () => {
        fence.sortDesc = rb.value === 'desc';
        if (!fence.sortBy || fence.sortBy === 'None') fence.sortBy = 'Name';
        saveState();
        renderAll();
      };
    });
    document.getElementById('sortModal').classList.remove('hidden');
  }

  // Top Dock Controls & Modals
  document.querySelectorAll('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.getElementById(btn.dataset.close).classList.add('hidden');
    });
  });

  document.getElementById('btnNewFence').addEventListener('click', () => {
    const title = prompt('Enter a title for the new fence:', 'New Fence');
    if (!title) return;
    state.fences.push({
      id: 'f-' + Date.now(),
      title: title.trim(),
      x: 260 + (state.fences.length * 30) % 240,
      y: 70 + (state.fences.length * 30) % 180,
      w: 360,
      h: 250,
      theme: 'Transparent',
      sortBy: 'None',
      sortDesc: false,
      holdLock: false,
      moveMode: 'Anywhere',
      rolledUp: false
    });
    saveState();
    renderAll();
  });

  document.getElementById('btnNewShortcut').addEventListener('click', () => {
    document.getElementById('shortcutModal').classList.remove('hidden');
  });

  document.getElementById('btnSaveShortcut').addEventListener('click', () => {
    const name = document.getElementById('scNameInput').value.trim() || 'New App';
    const url = document.getElementById('scUrlInput').value.trim() || 'https://example.com';
    const icon = document.getElementById('scIconInput').value.trim() || '🚀';
    const type = document.getElementById('scTypeInput').value;
    state.items.push({
      id: 'it-' + Date.now(),
      name,
      url,
      icon,
      bg: 'linear-gradient(135deg,#2563eb,#7c3aed)',
      size: 2048,
      type,
      modified: Date.now(),
      owner: 'desktop'
    });
    document.getElementById('shortcutModal').classList.add('hidden');
    saveState();
    renderAll();
  });

  document.getElementById('btnTransparentAll').addEventListener('click', () => {
    state.fences.forEach((f) => { f.theme = 'Transparent'; });
    saveState();
    renderAll();
  });

  document.getElementById('btnThemeMode').addEventListener('click', () => {
    state.isDarkMode = !state.isDarkMode;
    saveState();
    renderAll();
  });

  document.getElementById('wallpaperInput').addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      document.getElementById('wallpaperLayer').style.backgroundImage = `url(${reader.result})`;
    };
    reader.readAsDataURL(file);
  });

  // Cross-Platform PWA Install Prompt & Apple iOS / MacBook Guide
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
  });

  document.getElementById('btnOpenDownloads').addEventListener('click', () => {
    document.getElementById('downloadModal').classList.remove('hidden');
  });

  document.querySelectorAll('.pwa-trigger-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const platform = btn.dataset.platform;
      const banner = document.getElementById('installGuideBanner');

      if (deferredInstallPrompt) {
        deferredInstallPrompt.prompt();
        await deferredInstallPrompt.userChoice;
        deferredInstallPrompt = null;
        return;
      }

      banner.classList.remove('hidden');
      if (platform === 'ios') {
        banner.innerHTML = '📱 <strong>Install on iPhone / iPad (Safari):</strong> Tap the <strong>Share</strong> button <span style="padding:1px 5px;background:#1e293b;border-radius:4px">⎋</span> at the bottom of Safari, scroll down, and tap <strong>"Add to Home Screen"</strong>.';
      } else if (platform === 'mac') {
        banner.innerHTML = '🍎 <strong>Install on Apple MacBook:</strong> In <strong>Chrome / Edge</strong>, click the <strong>Install Desktop Fences</strong> icon in the right side of the address bar. In <strong>Safari (macOS Sonoma+)</strong>, click <strong>File → Add to Dock…</strong>.';
      } else {
        banner.innerHTML = '🤖 <strong>Install on Android:</strong> Tap the browser menu <strong>⋮</strong> in Chrome and select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.';
      }
    });
  });

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  renderAll();
})();
